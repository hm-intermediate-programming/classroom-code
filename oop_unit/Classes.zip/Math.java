/**
 * The Math class involves some simple arithmetic methods.
 * We will use this class to explore the concept of scope.
 */

class Math {
    final double pi = 3.14;

    public static void main(String[] args) throws Exception {
        Math m = new Math();
        System.out.println("This is the area of a circle of radius 2: "
                + m.area(2));
    }

    // Methods

    /**
     * Returns the area of a circle
     * 
     * @param r radius of circle
     */
    double area(double r) {
        return pi * r * r;
    }

    /**
     * Returns the circumference of a circle
     */
    double circumference() {
        return 2 * pi * r;
    }

    /**
     * Returns the area of a square
     * 
     * @param s length of square's side
     */
    double areaSquare(double s) {
        return s * s;
    }

}
