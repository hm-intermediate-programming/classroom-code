/**
 * This class represents a Bear in an ecosystem.
 */
class Bear {

    String type;
    int energy; 
    int hunger; 
    
    // Constructors 

    // Constructor A
    Bear(String type, int energy, int hunger) {
        this.type = type;
        this.energy = energy; 
        this.hunger = hunger;
    }
    
    // Constructor B
    Bear(String type) {
        this.type = type;
        this.energy = 0; 
        this.hunger = 100;
    }
  
    // Methods
  
    /**
     * Change energy and hunger according to how much is eaten
     * @param amount  the amount of food the bear eats
     */
    void eat(int amount){
      energy += amount; // Equivalent to this.energy = this.energy + amount;
      hunger = hunger - amount;
    }
  
    /**
     * Return how hungry the bear is
     */
    int getHunger() {
      return hunger;
    }
  }